<?php
header("Content-Type: application/json");

if(!empty($_FILES['file'])){
    echo "hello";
}

?>