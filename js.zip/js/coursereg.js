function confirmRegistration() {
    // Use AJAX to check if the user is already registered
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'check_registration.php', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            if (xhr.responseText === 'already_registered') {
                if (confirm("You have already registered for courses. YOU CANNOT REGISTER AGAIN!")) {
                    document.getElementById('course_reg_form').submit();
                }

            } else {
       
                document.getElementById('course_reg_form').submit(alert('You have succefully registered for courses!'));
            }
        }
    
    };
    xhr.send();
    
    return false; // Prevent form submission until the AJAX request completes
}
