<?php
define ('DB_USER', "root");
define ('DB_PASSWORD', "");
define ('DB_DATABASE', "managementportal");
define ('DB_HOST', "localhost");
?>
